
const tabs = ['stock','items','receive','bom','wo'];
for(const t of tabs){
  document.getElementById('tab-'+t).addEventListener('click', ()=>show(t));
}
function show(name){
  for(const t of tabs){
    document.getElementById('tab-'+t).classList.toggle('active', t===name);
    document.getElementById('view-'+t).classList.toggle('shown', t===name);
  }
  if(name==='stock') loadStock();
  if(name==='items') loadItems();
}
async function loadStock(){
  const res = await fetch('/api/stock'); const data = await res.json();
  const tbody = document.querySelector('#stock-table tbody'); tbody.innerHTML='';
  data.forEach(r=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td>${r.sku}</td><td>${r.name}</td><td>${r.type_code}</td><td>${r.unit}</td>
                  <td>${r.on_hand}</td><td>${r.avg_cost}</td><td>${r.stock_value}</td>`;
    tbody.appendChild(tr);
  });
}
async function loadItems(){
  const res = await fetch('/api/items'); const data = await res.json();
  const tbody = document.querySelector('#items-table tbody'); tbody.innerHTML='';
  data.forEach(r=>{
    const tr=document.createElement('tr');
    tr.innerHTML=`<td>${r.sku}</td><td>${r.name}</td><td>${r.type_code}</td><td>${r.unit}</td><td>${r.avg_cost}</td>`;
    tbody.appendChild(tr);
  });
}
document.getElementById('form-item').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  const res = await fetch('/api/items', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const out = await res.json();
  document.getElementById('item-result').textContent = res.ok ? `SKU created: ${out.sku}` : `Error: ${out.error}`;
  loadItems();
  e.target.reset();
});
document.getElementById('form-receive').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  payload.qty = parseFloat(payload.qty);
  payload.unit_cost = parseFloat(payload.unit_cost);
  const res = await fetch('/api/receive', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const out = await res.json();
  document.getElementById('receive-result').textContent = res.ok ? `Batch: ${out.batch_code} | New avg: ${out.new_avg_cost.toFixed(4)}` : `Error: ${out.error}`;
  loadStock();
  e.target.reset();
});
document.getElementById('form-product').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  const res = await fetch('/api/products', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const out = await res.json();
  document.getElementById('prod-result').textContent = res.ok ? `Product created: ${out.code}` : `Error: ${out.error}`;
  e.target.reset();
});
document.getElementById('form-bom').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  payload.qty_per = parseFloat(payload.qty_per);
  const res = await fetch(`/api/products/${payload.product_code}/bom`, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const out = await res.json();
  document.getElementById('bom-result').textContent = res.ok ? `BOM row added` : `Error: ${out.error}`;
  e.target.reset();
});
document.getElementById('form-wo').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const payload = Object.fromEntries(fd.entries());
  payload.quantity = parseFloat(payload.quantity);
  const res = await fetch('/api/workorders', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)});
  const out = await res.json();
  document.getElementById('wo-result').textContent = res.ok ? `WO created: ${out.code}` : `Error: ${out.error}`;
  e.target.reset();
});
document.getElementById('form-wo-complete').addEventListener('submit', async (e)=>{
  e.preventDefault();
  const fd = new FormData(e.target);
  const code = fd.get('wo_code');
  const res = await fetch(`/api/workorders/${code}/complete`, {method:'POST'});
  const out = await res.json();
  document.getElementById('woc-result').textContent = res.ok ? `Completed at ${out.completed_at}` : `Error: ${out.error}`;
  loadStock();
  e.target.reset();
});
// init
loadStock();
